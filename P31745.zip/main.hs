flatten :: [[Int]] -> [Int]

flatten xs = foldl (++) [] xs

myLength :: String -> Int

myLength x = foldl (+) 0 (map (const 1) x)

myReverse :: [Int] -> [Int]

myReverse x = map last (take (length x) (iterate init x))

countIn :: [[Int]] -> Int -> [Int]

countIn xs x = map (foldl sumEq 0) xs
    where 
      sumEq :: Int -> Int -> Int
      sumEq a b 
        | b == x = a + 1
        | otherwise = a

firstWord :: String -> String

firstWord xs = takeWhile (/= ' ') (dropWhile (== ' ') xs)