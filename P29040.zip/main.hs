insert :: [Int] -> Int -> [Int] 

insert [] y = [y]
insert (x:xs) y 
  | x >= y = y : (x:xs)
  | otherwise = x : (insert xs y)   

isort :: [Int] -> [Int]

isort [] = []
isort (x:xs) = insert (isort xs) x

remove :: [Int] -> Int -> [Int]

remove [] y = []
remove (x:xs) y 
  | x == y = xs
  | otherwise = x : remove xs y

ssort :: [Int] -> [Int]

ssort [] = []
ssort xs = insert (ssort (remove xs (minimum xs))) (minimum xs)

merge :: [Int] -> [Int] -> [Int]

merge xs [] = xs
merge [] ys = ys
merge (x:xs) (y:ys)
  | x <= y = x : (merge xs (y:ys))
  | otherwise = y : (merge (x:xs) ys)
msort :: [Int] -> [Int]

msort [] = []
msort [a] = [a]
msort xs = merge (msort a) (msort b) where (a,b) = split xs

split :: [Int] -> ([Int],[Int])

split [] = ([],[])
split xs = (take (div (length xs) 2) xs, drop (div (length xs) 2) xs)

qsort :: [Int] -> [Int]

qsort [] = [] 
qsort (x:xs) = qsort(menors x xs) ++ [x] ++ qsort(majors x xs)

menors :: Int -> [Int] -> [Int]

menors x [] = []
menors x (y:ys)
  | x > y = y : (menors x ys)
  | otherwise = menors x ys

majors :: Int -> [Int] -> [Int]

majors x [] = []
majors x (y:ys)
  | x <= y = y : (majors x ys)
  | otherwise = majors x ys

genQsort :: Ord a => [a] -> [a]

genQsort [] = [] 
genQsort (x:xs) = genQsort(genMenors x xs) ++ [x] ++ genQsort(genMajors x xs)

genMenors :: Ord a => a -> [a] -> [a]

genMenors x [] = []
genMenors x (y:ys)
  | x > y = y : (genMenors x ys)
  | otherwise = genMenors x ys

genMajors :: Ord a => a -> [a] -> [a]

genMajors x [] = []
genMajors x (y:ys)
  | x <= y = y: (genMajors x ys)
  | otherwise = genMajors x ys 


