pam:: [Int] -> [Int -> Int] -> [[Int]] 

pam xs ys = [ [ f x | x <- xs ] | f <- ys ]

pam2 :: [Int] -> [Int -> Int] -> [[Int]]

pam2 xs ys = [ [ f x | f <- ys] | x <- xs ]

filterFoldl :: (Int -> Bool) -> (Int -> Int -> Int) -> Int -> [Int] -> Int

filterFoldl b f x xs = foldl f x (filter b xs)

insert :: (Int -> Int -> Bool) -> [Int] -> Int -> [Int]

insert f [] y = [y]
insert f (x:xs) y 
  | f x y = x : insert f xs y
  | otherwise = y : x : xs 

insertionSort :: (Int -> Int -> Bool) -> [Int] -> [Int]

insertionSort f xs = foldl (insert f) [] xs

countIf :: (Int -> Bool) -> [Int] -> Int

countIf p xs = length (filter p xs)