myLength :: [Int] -> Int 

myLength [] = 0
myLength (x:xs) = 1 + myLength xs

myMaximum :: [Int] -> Int

myMaximum (x:xs) = partialMax x xs

partialMax :: Int -> [Int] -> Int

partialMax n [] = n
partialMax n (x:xs)
  | n >= x = partialMax n xs
  | otherwise = partialMax x xs

average :: [Int] -> Float

average xs = fromIntegral(div (listSum xs) (myLength xs))

listSum :: [Int] -> Int

listSum [] = 0
listSum (x:xs) = x + listSum xs

buildPalindrome :: [Int] -> [Int]

buildPalindrome xs = reverse xs ++ xs

remove :: [Int] -> [Int] -> [Int]

remove xs [] = xs
remove [] ys = []
remove xs (y:ys) = remove (singleRemove xs y) ys

singleRemove :: [Int] -> Int -> [Int]

singleRemove (x:xs) y
  | x == y && xs /= [] = singleRemove xs y
  | x /= y && xs /= [] = x : singleRemove xs y
  | x == y && xs == [] = []
  | x /= y && xs == [] = [x]

flatten :: [[Int]] -> [Int]

flatten [] = []
flatten (x:xs) = x ++ flatten xs

oddsNevens :: [Int] -> ([Int],[Int])

oddsNevens [] = ([],[])
oddsNevens xs = (odds xs, evens xs)

odds :: [Int] -> [Int]

odds [] = []
odds (x:xs)
  | mod x 2 /= 0 = x : odds(xs)
  | otherwise = odds(xs)

evens :: [Int] -> [Int]

evens [] = []
evens (x:xs)
  | mod x 2 == 0 = x : evens(xs)
  | otherwise = evens(xs)


primeDivisors :: Int -> [Int]

primeDivisors 0 = []
primeDivisors n = primDiv n 2

isPrime :: Int -> Bool

isPrime 0 = False
isPrime 1 = False
isPrime n = primeDivision n 2

primeDivision :: Int -> Int -> Bool

primeDivision n m 
    | m == n = True
    | mod n m == 0 = False
    | otherwise = primeDivision n (m + 1)

primDiv :: Int -> Int -> [Int]

primDiv n m 
  | (n >= m) && (isPrime m) && (mod n m == 0) = m : primDiv n (m+1)
  | (n >= m) && (not(isPrime m) || (mod n m /= 0)) = primDiv n (m+1)
  | otherwise = []


